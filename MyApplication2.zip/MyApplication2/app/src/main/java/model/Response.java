package model;

import java.util.ArrayList;
import java.util.List;

import model.AndroidVersion;

public class Response {

    private List<AndroidVersion> user = new ArrayList<AndroidVersion>();

    public List<AndroidVersion> getUser() {
        return user;
    }
}