package model;

public class AndroidVersion {

    private String Name;
    private String Reg;


    public String getName() {
        return Name;
    }

    public String getReg() {
        return Reg;
    }

}